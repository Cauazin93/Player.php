<?php
class Defesa extends Item {
    public function __construct(string $name) {
        parent::__construct($name, 4, 'Item de defesa');
    }
}


?>